package com.demo.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.demo.Entity.Payment;
import com.demo.Model.PaymentDTO;
import com.demo.Service.PaymentService;



@RestController
@RequestMapping("/api/payments")
public class PaymentController 
{

    @Autowired
    private PaymentService paymentService;

    // Create a new Payment
    @PostMapping
    public ResponseEntity<String> createPayment(@RequestBody PaymentDTO paymentDTO) 
    {
        String response = paymentService.createPayment(paymentDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get a payment by ID
    @GetMapping("/{PaymentId}")
    public ResponseEntity<PaymentDTO> getPaymentById(@PathVariable Long PaymentId)
    {
        PaymentDTO paymentDTO = paymentService.getPaymentByPaymentId(PaymentId);
        return new ResponseEntity<>(paymentDTO, HttpStatus.OK);
    }

    // Get all payments
    @GetMapping
    public ResponseEntity<List<PaymentDTO>> getAllPayments()
    {
        List<PaymentDTO> paymentsList = paymentService.getAllPayments();
        return new ResponseEntity<>(paymentsList, HttpStatus.OK);
    }

    
    @PutMapping("/{PaymentId}")
    public ResponseEntity<PaymentDTO> updatePayment(@PathVariable Long PaymentId, @RequestBody Payment paymentDTO)
    {
        PaymentDTO updatedPayment = paymentService.updatePayment(PaymentId, paymentDTO);
        return new ResponseEntity<>(updatedPayment, HttpStatus.OK);
    }
 
    @DeleteMapping("/{PaymentId}")
    public ResponseEntity<String> deletePayment(@PathVariable Long PaymentId)
    {
        String response = paymentService.deletePayment(PaymentId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/bookingid/{bookingid}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByBookingId(@PathVariable String bookingid) 
    {
        List<PaymentDTO> paymentsList = paymentService.getPaymentsByBookingId(bookingid);
        return new ResponseEntity<>(paymentsList, HttpStatus.OK);
    }
    
    @GetMapping("/paymentdate/{paymentdate}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByPaymentDate(@PathVariable String paymentdate) 
    {
        List<PaymentDTO> paymentsList = paymentService.getPaymentsByPaymentDate(paymentdate);
        return new ResponseEntity<>(paymentsList, HttpStatus.OK);
    }
    
    @GetMapping("/paymentamount/{paymentamount}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByPaymentAmount(@PathVariable String paymentamount) 
    {
        List<PaymentDTO> paymentsList = paymentService.getPaymentsByPaymentAmount(paymentamount);
        return new ResponseEntity<>(paymentsList, HttpStatus.OK);
    }
    

    @GetMapping("/paymentstatus/{paymentstatus}")
    public ResponseEntity<List<PaymentDTO>> getPaymentsByPaymentStatus(@PathVariable String paymentstatus) 
    {
        List<PaymentDTO> paymentsList = paymentService.getPaymentsByPaymentStatus(paymentstatus);
        return new ResponseEntity<>(paymentsList, HttpStatus.OK);
    }
    
    
    
 }
