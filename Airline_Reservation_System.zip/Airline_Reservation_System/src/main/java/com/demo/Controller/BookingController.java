package com.demo.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.Entity.Booking;
import com.demo.Model.BookingDTO;
import com.demo.Service.BookingService;


@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Create a new patient
    @PostMapping
    public ResponseEntity<String> createBooking(@RequestBody BookingDTO bookingDTO) 
    {
        String response = bookingService.createBooking(bookingDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get a patient by ID
    @GetMapping("/{Id}")
    public ResponseEntity<BookingDTO> getBookingById(@PathVariable Long Id)
    {
        BookingDTO bookingDTO = bookingService.getBookingById(Id);
        return new ResponseEntity<>(bookingDTO, HttpStatus.OK);
    }

    // Get all patients
    @GetMapping
    public ResponseEntity<List<BookingDTO>> getAllBookings()
    {
        List<BookingDTO> bookingsList = bookingService.getAllBookings();
        return new ResponseEntity<>(bookingsList, HttpStatus.OK);
    }

    // Update an existing patient by ID
    @PutMapping("/{Id}")
    public ResponseEntity<BookingDTO> updateBooking(@PathVariable Long Id, @RequestBody Booking bookingDTO)
    {
        BookingDTO updatedBooking = bookingService.updateBooking(Id, bookingDTO);
        return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
    }
   
    // Delete a Admin by ID
    @DeleteMapping("/{Id}")
    public ResponseEntity<String> deleteBooking(@PathVariable Long Id)
    {
        String response = bookingService.deleteBooking(Id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Get patients by diagnosis
    
    @GetMapping("/type/{type}")
    public ResponseEntity<List<BookingDTO>> getBookingsByType(@PathVariable String type) 
    {
        List<BookingDTO> bookingsList = bookingService.getBookingsByType(type);
        return new ResponseEntity<>(bookingsList, HttpStatus.OK);
    }
    
    @GetMapping("/date/{date}")
    public ResponseEntity<List<BookingDTO>> getBookingsByDate(@PathVariable String date) 
    {
        List<BookingDTO> bookingsList = bookingService.getBookingsByDate(date);
        return new ResponseEntity<>(bookingsList, HttpStatus.OK);
    }
    
    @GetMapping("/user_id/{user_id}")
    public ResponseEntity<List<BookingDTO>> getBookinsByUser_Id(@PathVariable String user_id) 
    {
        List<BookingDTO> bookingsList = bookingService.getBookingsByUser_Id(user_id);
        return new ResponseEntity<>(bookingsList, HttpStatus.OK);
    }
    
    
 }
