package com.demo.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.Entity.Ticket;
import com.demo.Model.TicketDTO;
import com.demo.Service.TicketService;


@RestController
@RequestMapping("/api/tickets")
public class TicketController
{

    @Autowired
    private TicketService ticketService;

    
    @PostMapping
    public ResponseEntity<String> createTicket(@RequestBody TicketDTO ticketDTO) 
    {
        String response = ticketService.createTicket(ticketDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

  
    @GetMapping("/{TicketId}")
    public ResponseEntity<TicketDTO> getTicketByTicketId(@PathVariable Long TicketId)
    {
        TicketDTO ticketDTO = ticketService.getTicketByTicketId(TicketId);
        return new ResponseEntity<>(ticketDTO, HttpStatus.OK);
    }

    
    @GetMapping
    public ResponseEntity<List<TicketDTO>> getAllTickets()
    {
        List<TicketDTO> ticketsList = ticketService.getAllTickets();
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }

    
    @PutMapping("/{TicketId}")
    public ResponseEntity<TicketDTO> updateTicket(@PathVariable Long TicketId, @RequestBody Ticket ticketDTO)
    {
        TicketDTO updatedTicket = ticketService.updateTicket(TicketId, ticketDTO);
        return new ResponseEntity<>(updatedTicket, HttpStatus.OK);
    }
   
   
    @DeleteMapping("/{TicketId}")
    public ResponseEntity<String> deleteTicket(@PathVariable Long TicketId)
    {
        String response = ticketService.deleteTicket(TicketId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    
    @GetMapping("/user_id/{user_id}")
    public ResponseEntity<List<TicketDTO>> getTicketsByUser_Id(@PathVariable String user_id) 
    {
        List<TicketDTO> ticketsList = ticketService.getTicketsByUser_Id(user_id);
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }
    
    @GetMapping("/flight_id/{flight_id}")
    public ResponseEntity<List<TicketDTO>> getTicketsByDate(@PathVariable String flight_id) 
    {
        List<TicketDTO> ticketsList = ticketService.getTicketsByFlight_Id(flight_id);
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }
    
    @GetMapping("/seatnumber/{seatnumber}")
    public ResponseEntity<List<TicketDTO>> getTicketBySeatNumber(@PathVariable String seatnumber) 
    {
        List<TicketDTO> ticketsList = ticketService.getTicketsBySeatNumber(seatnumber);
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }
    
    @GetMapping("/ticketstatus/{ticketstatus}")
    public ResponseEntity<List<TicketDTO>> getTicketByTicketStatus(@PathVariable String ticketstatus) 
    {
        List<TicketDTO> ticketsList = ticketService.getTicketsByTicketStatus(ticketstatus);
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }
    
    @GetMapping("/ticketprice/{ticketprice}")
    public ResponseEntity<List<TicketDTO>> getTicketByTicketPrice(@PathVariable String ticketprice) 
    {
        List<TicketDTO> ticketsList = ticketService.getTicketsByTicketPrice(ticketprice);
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }
    
    @GetMapping("/bookingdate/{bookingdate}")
    public ResponseEntity<List<TicketDTO>> getTicketByBookingDate(@PathVariable String bookingdate) 
    {
        List<TicketDTO> ticketsList = ticketService.getTicketsByBookingDate(bookingdate);
        return new ResponseEntity<>(ticketsList, HttpStatus.OK);
    }
    
    
 }
