package com.demo.Controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.Entity.Enquiry;
import com.demo.Model.EnquiryDTO;
import com.demo.Service.EnquiryService;


@RestController
@RequestMapping("/api/enquirys")
public class EnquiryController 
{

    @Autowired
    private EnquiryService enquiryService;

    // Create a new enquiry
    @PostMapping
    public ResponseEntity<String> createEnquiry(@RequestBody EnquiryDTO enquiryDTO) 
    {
        String response = enquiryService.createEnquiry(enquiryDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get a Enquiry by ID
    @GetMapping("/{Id}")
    public ResponseEntity<EnquiryDTO> getEnquiryById(@PathVariable Long Id)
    {
        EnquiryDTO enquiryDTO = enquiryService.getEnquiryById(Id);
        return new ResponseEntity<>(enquiryDTO, HttpStatus.OK);
    }

    // Get all enquirys
    @GetMapping
    public ResponseEntity<List<EnquiryDTO>> getAllEnquirys()
    {
        List<EnquiryDTO> enquirysList = enquiryService.getAllEnquirys();
        return new ResponseEntity<>(enquirysList, HttpStatus.OK);
    }

    // Update an existing enquiry by ID
    @PutMapping("/{Id}")
    public ResponseEntity<EnquiryDTO> updateEnquiry(@PathVariable Long Id, @RequestBody Enquiry enquiryDTO)
    {
        EnquiryDTO updatedEnquiry = enquiryService.updateEnquiry(Id, enquiryDTO);
        return new ResponseEntity<>(updatedEnquiry, HttpStatus.OK);
    }
   
    // Delete a Admin by ID
    @DeleteMapping("/{Id}")
    public ResponseEntity<String> deleteEnquiry(@PathVariable Long Id)
    {
        String response = enquiryService.deleteEnquiry(Id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/title/{title}")
    public ResponseEntity<List<EnquiryDTO>> getEnquirysByTitle(@PathVariable String title) 
    {
        List<EnquiryDTO> enquirysList = enquiryService.getEnquirysByTitle(title);
        return new ResponseEntity<>(enquirysList, HttpStatus.OK);
    }
    
    @GetMapping("/type/{type}")
    public ResponseEntity<List<EnquiryDTO>> getEnquirysByType(@PathVariable String type) 
    {
        List<EnquiryDTO> enquirysList = enquiryService.getEnquirysByType(type);
        return new ResponseEntity<>(enquirysList, HttpStatus.OK);
    }
    
    @GetMapping("/date/{date}")
    public ResponseEntity<List<EnquiryDTO>> getEnquirysByDate(@PathVariable String date) 
    {
        List<EnquiryDTO> enquirysList = enquiryService.getEnquirysByDate(date);
        return new ResponseEntity<>(enquirysList, HttpStatus.OK);
    }
    
    @GetMapping("/user_id/{user_id}")
    public ResponseEntity<List<EnquiryDTO>> getEnquirysByUser_Id(@PathVariable String user_id) 
    {
        List<EnquiryDTO> enquirysList = enquiryService.getEnquirysByUser_Id(user_id);
        return new ResponseEntity<>(enquirysList, HttpStatus.OK);
    }
    
    
 }
