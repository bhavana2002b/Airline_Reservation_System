package com.demo.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.Entity.User;
import com.demo.Model.UserDTO;
import com.demo.Service.UserService;


@RestController
@RequestMapping("/api/users")
public class UserController 
{

    @Autowired
    private UserService userService;

    // Create a new user
    @PostMapping
    public ResponseEntity<String> createUser(@RequestBody UserDTO userDTO) 
    {
        String response = userService.createUser(userDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get a user by ID
    @GetMapping("/{Id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable Long Id)
    {
        UserDTO userDTO = userService.getUserById(Id);
        return new ResponseEntity<>(userDTO, HttpStatus.OK);
    }

    // Get all users
    @GetMapping
    public ResponseEntity<List<UserDTO>> getAllUsers()
    {
        List<UserDTO> usersList = userService.getAllUsers();
        return new ResponseEntity<>(usersList, HttpStatus.OK);
    }

    // Update an existing user by ID
    @PutMapping("/{Id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable Long Id, @RequestBody User userDTO)
    {
        UserDTO updatedUser = userService.updateUser(Id, userDTO);
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }
   
    // Delete a User by ID
    @DeleteMapping("/{Id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long Id)
    {
        String response = userService.deleteUser(Id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    
    @GetMapping("/name/{name}")
    public ResponseEntity<List<UserDTO>> getUsersByName(@PathVariable String name) 
    {
        List<UserDTO> usersList = userService.getUsersByname(name);
        return new ResponseEntity<>(usersList, HttpStatus.OK);
    }
    
    @GetMapping("/mobileno/{mobileno}")
    public ResponseEntity<List<UserDTO>> getUsersByMobileNo(@PathVariable String mobileno) 
    {
        List<UserDTO> usersList = userService.getUsersByMobileNo(mobileno);
        return new ResponseEntity<>(usersList, HttpStatus.OK);
    }
    
    @GetMapping("/emailid/{emailid}")
    public ResponseEntity<List<UserDTO>> getUsersByEmailId(@PathVariable String emailid) 
    {
        List<UserDTO> usersList = userService.getUsersByEmailId(emailid);
        return new ResponseEntity<>(usersList, HttpStatus.OK);
    }
    
    
 }
