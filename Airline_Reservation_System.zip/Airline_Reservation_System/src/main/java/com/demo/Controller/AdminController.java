package com.demo.Controller;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.Entity.Admin;
import com.demo.Model.AdminDTO;
import com.demo.Service.AdminService;

@RestController
@RequestMapping("/api/admins")
public class AdminController
{

    @Autowired
    private AdminService adminService;

    // Create a new patient
    @PostMapping
    public ResponseEntity<String> createAdmin(@RequestBody AdminDTO adminDTO) 
    {
        String response = adminService.createAdmin(adminDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get a admin by ID
    @GetMapping("/{adminId}")
    public ResponseEntity<AdminDTO> getAdminById(@PathVariable Long Id)
    {
        AdminDTO adminDTO = adminService.getAdminById(Id);
        return new ResponseEntity<>(adminDTO, HttpStatus.OK);
    }

    // Get all admins
    @GetMapping
    public ResponseEntity<List<AdminDTO>> getAllAdmins() {
        List<AdminDTO> adminsList = adminService.getAllAdmins();
        return new ResponseEntity<>(adminsList, HttpStatus.OK);
    }

    
    // Update an existing patient by ID
    @PutMapping("/{Id}")
    public ResponseEntity<AdminDTO> updateAdmin(@PathVariable Long Id, @RequestBody Admin adminDTO)
    {
        AdminDTO updatedAdmin = adminService.updateAdmin(Id, adminDTO);
        return new ResponseEntity<>(updatedAdmin, HttpStatus.OK);
    }
   
    // Delete a Admin by ID
    @DeleteMapping("/{Id}")
    public ResponseEntity<String> deleteAdmin(@PathVariable Long Id)
    {
        String response = adminService.deleteAdmin(Id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Get patients by diagnosis
    
    @GetMapping("/username/{username}")
    public ResponseEntity<List<AdminDTO>> getAdminsByUsername(@PathVariable String username) 
    {
        List<AdminDTO> adminsList = adminService.getAdminsByUsername(username);
        return new ResponseEntity<>(adminsList, HttpStatus.OK);
    }
    
    @GetMapping("/password/{password}")
    public ResponseEntity<List<AdminDTO>> getAdminsByPassword(@PathVariable String password) 
    {
        List<AdminDTO> adminsList = adminService.getAdminsByPassword(password);
        return new ResponseEntity<>(adminsList, HttpStatus.OK);
    }
    
    @GetMapping("/email/{email}")
    public ResponseEntity<List<AdminDTO>> getAdminsByEmail(@PathVariable String email) 
    {
        List<AdminDTO> adminsList = adminService.getAdminsByEmail(email);
        return new ResponseEntity<>(adminsList, HttpStatus.OK);
    }
    
    @GetMapping("/fullname/{fullname}")
    public ResponseEntity<List<AdminDTO>> getAdminsByFullName(@PathVariable String fullname) 
    {
        List<AdminDTO> adminsList = adminService.getAdminsByFullName(fullname);
        return new ResponseEntity<>(adminsList, HttpStatus.OK);
    }
    
    
    
    
    

    
}
