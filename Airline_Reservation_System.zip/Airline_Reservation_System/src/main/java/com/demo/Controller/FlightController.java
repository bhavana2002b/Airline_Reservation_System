package com.demo.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.demo.Entity.Flight;
import com.demo.Model.FlightDTO;
import com.demo.Service.FlightService;

@RestController
@RequestMapping("/api/flights")
public class FlightController
{

    @Autowired
    private FlightService flightService;

    // Create a new flight
    @PostMapping
    public ResponseEntity<String> createFlight(@RequestBody FlightDTO flightDTO) 
    {
        String response = flightService.createFlight(flightDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get a flight by ID
    @GetMapping("/{Id}")
    public ResponseEntity<FlightDTO> getflightById(@PathVariable Long Id)
    {
        FlightDTO flightDTO = flightService.getFlightById(Id);
        return new ResponseEntity<>(flightDTO, HttpStatus.OK);
    }

    // Get all flights
    @GetMapping
    public ResponseEntity<List<FlightDTO>> getAllFlights() {
        List<FlightDTO> flightsList = flightService.getAllFlights();
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }

    @PutMapping("/{Id}")
    public ResponseEntity<FlightDTO> updateFlight(@PathVariable Long Id, @RequestBody Flight flightDTO)
    {
        FlightDTO updatedFlight = flightService.updateFlight(Id, flightDTO);
        return new ResponseEntity<>(updatedFlight, HttpStatus.OK);
    }
   
    // Delete a Flight by ID
    @DeleteMapping("/{Id}")
    public ResponseEntity<String> deleteFlight(@PathVariable Long Id)
    {
        String response = flightService.deleteFlight(Id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

   
    
    @GetMapping("/flightnumber/{flightnumber}")
    public ResponseEntity<List<FlightDTO>> getFlightsByFlightNumber(@PathVariable String flightnumber) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByFlightNumber(flightnumber);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/departureairport/{departureairport}")
    public ResponseEntity<List<FlightDTO>> getFlightsByDepartureAirport(@PathVariable String departureairport) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByDepartureAirport(departureairport);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/DestinationAirport/{destinationairport}")
    public ResponseEntity<List<FlightDTO>> getFlightsByDestinationAirport(@PathVariable String destinationairport) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByDestinationAirport(destinationairport);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/departuredatetime/{destinationdatetime}")
    public ResponseEntity<List<FlightDTO>> getFlightsByDepartureDatetime(@PathVariable String departuredatetime) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByDepartureDatetime(departuredatetime);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/arrivaldatetime/{arrivaldatetime}")
    public ResponseEntity<List<FlightDTO>> getFlightsByArrivaleDatetime(@PathVariable String arrivaldatetime) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByArrivalDatetime(arrivaldatetime);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/totalseats/{totalseats}")
    public ResponseEntity<List<FlightDTO>> getFlightsByTotalSeats(@PathVariable String totalseats) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByTotalSeats(totalseats);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/availableseats/{availableseats}")
    public ResponseEntity<List<FlightDTO>> getFlightsByAvailableSeats(@PathVariable String availableseats) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByAvailableSeats(availableseats);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    @GetMapping("/ticketprice/{ticketprice}")
    public ResponseEntity<List<FlightDTO>> getFlightsByTicketPrice(@PathVariable String ticketprice) 
    {
        List<FlightDTO> flightsList = flightService.getFlightsByTicketPrice(ticketprice);
        return new ResponseEntity<>(flightsList, HttpStatus.OK);
    }
    
    
    
    

    
}
