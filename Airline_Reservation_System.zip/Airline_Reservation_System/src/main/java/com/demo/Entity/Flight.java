package com.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Flight
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id",length= 20)
    private Long Id;
    @Column(name="FlightNumber",length= 30)
    private String flightnumber;
    
    @Column(name="DepartureAirport",length = 30)
    private String departureairport;
    
    @Column(name="DestinationAirport",length = 30)
    private String destinationairport;
    
    @Column(name="DepartureDatetime",length = 30)
    private String departuredatetime;
    
    @Column(name="DestinationDatetime",length = 30)
    private String destinationdatetime;
    
    @Column(name="ArrivalDatetime",length = 30)
    private String arrivaldatetime;
    
    @Column(name="TotalSeats",length = 30)
    private String totalseats;
    
    @Column(name="AvailableSeats",length = 30)
    private String availableseats;
    
    @Column(name="TicketPrice",length = 30)
    private String ticketprice;
    
    public Long getId()
    {
		return Id;
	}

	public void setId(Long Id) 
	{
		this.Id = Id;
	}

	public String getFlightNumber()
	{
		return flightnumber;
	}

	public void setFlightNumber(String flightnumber) 
	{
		this.flightnumber = flightnumber;
	}
	

	public String getDepartureAirport() 
	{
		return departureairport;
	}

	public void setDepartureAirport(String departureairport) 
	{
		this.departureairport = departureairport;
	}

	public String getDestinationAirport() 
	{
		return destinationairport;
	}

	public void setDestinationAirport(String destinationairport) 
	{
		this.destinationairport = destinationairport;
	}
	
	public String getDepartureDatetime() 
	{
		return departuredatetime;
	}

	public void setDepartureDatetime(String departuredatetime) 
	{
		this.departuredatetime = departuredatetime;
	}
	
	public String getDestinationDatetime() 
	{
		return destinationdatetime;
	}

	public void setDestinationDatetime(String destinationdatetime) 
	{
		this.destinationdatetime = destinationdatetime;
	}
	
	public String getArrivalDatetime() 
	{
		return arrivaldatetime;
	}

	public void setArrivalDatetime(String arrivaldatetime) 
	{
		this.arrivaldatetime = arrivaldatetime;
	}
	
	public String getTotalSeats() 
	{
		return totalseats;
	}

	public void setTotalSeats(String totalseats) 
	{
		this.totalseats = totalseats;
	}
  
	public String getAvailableSeats() 
	{
		return availableseats;
	}

	public void setAvailableSeats(String availableseats) 
	{
		this.availableseats = availableseats;
	}
	
	public String getTicketPrice() 
	{
		return ticketprice;
	}

	public void setTicketPrice(String ticketprice) 
	{
		this.ticketprice = ticketprice;
	}
	
	

	
    
}

    
    


