package com.demo.Entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Entity
public class Payment
{

		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    @Column(name="PaymentId",length= 20)
		    private Long paymentid;

		    
		    @Column(name="PaymentAmount",length= 20)
		    private Double paymentamount;
		    
		    @Column(name="PaymentStatus",length= 20)
		    private String paymentstatus;
		    
		    @ManyToOne
		    @JoinColumn(name = "bookingId")
		    @Column(name="booking",length= 20)
		    private Booking bookingid;

		    @ManyToOne
		    @Column(name="PaymentDate",length= 20)
		    private LocalDate paymentdate;
		    
		    private String BookingId;
		    private Long PaymentDate;
		   
		    
		    public Long getPaymentId()
		    {
				return paymentid;
			}

			public void setPaymentId(Long paymentid) 
			{
				this.paymentid = paymentid;
			}

			public Double getPaymentAmount()
			{
				return paymentamount;
			}

			public void setPaymentAmount(Double paymentamount) 
			{
				this.paymentamount = paymentamount;
			}
			

			public String getPaymentStatus() 
			{
				return paymentstatus;
			}

			public void setPaymentStatus(String paymentstatus) 
			{
				this.paymentstatus = paymentstatus;
			}

			public String getBookingId() 
			{
				return BookingId;
			}

			public void setBookingId(String bookingId)
			{
				BookingId = bookingId;
			}

			public Long getPaymentDate() 
			{
				return PaymentDate;
			}

			public void setPaymentDate(Long paymentDate) 
			{
				PaymentDate = paymentDate;
			}

			

			

			
}
		
