package com.demo.Entity;


import javax.persistence.Entity;


import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Entity
public class Ticket 
{

		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    @Column(name="TicketId",length= 20)
		    private Long TicketId;

		    @ManyToOne
		    @JoinColumn(name = "User_Id")
		    @Column(name="user",length= 20)
		    private User user;
		    
		    @ManyToOne
		    @JoinColumn(name = "Flight_Id")
		    @Column(name="flight",length= 20)
		    private Flight flight;
		    

		    @ManyToOne
		    @Column(name="SeatNumber",length= 20)
		    private String seatnumber;
		    
		    @Column(name="TicketStatus",length= 20)
		    private Double ticketstatus;
		    
		    @Column(name="TicketPrice",length= 20)
		    private String ticketprice;
		    
		    @Column(name="BookingDate",length = 30)
		    private String bookingdate;

		    private String User_Id;
		    private String Flight_Id;

			

		    public Long getTicketId()
		    {
				return TicketId;
			}

			public void setTicketId(Long TicketId) 
			{
				this.TicketId = TicketId;
			}
			
			public String getUser_Id() 
			{
				return User_Id;
			}

			public void setUser_Id(String user_Id) 
			{
				User_Id = user_Id;
			}
			
            public String getFlight_Id()
			{
				return Flight_Id;
			}

			public void setFlight_Id(String flight_Id)
			{
				Flight_Id = flight_Id;
			}


			public String getSeatNumber() 
			{
				return seatnumber;
			}

			public void setSeatNumber(String seatnumber) 
			{
				this.seatnumber= seatnumber;
			}

			public Double getTicketStatus() 
			{
				return ticketstatus;
			}

			public void setTicketStatus(Double ticketstatus)
			{
				this.ticketstatus= ticketstatus;
			}
			
			public String getTicketPrice()
            {
				return ticketprice;
			}

			public void setTicketPrice(String ticketprice)
			{
				this.ticketprice = ticketprice;
			}
			

			public String getBookingDate()
			{
				return bookingdate;
			}

			public void setBookingDate(String bookingdate) 
			{
				this.bookingdate = bookingdate;
			}



			


		    

}
		
