package com.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Booking
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id",length= 20)
    private Long Id;
    
    @Column(name="Type",length= 30)
    private String type;
    
    @Column(name="Date",length = 30)
    private String date;
    
    @ManyToOne
    @JoinColumn(name = "User_Id")
    @Column(name="user",length= 20)
    private User user;

	private String User_id;

	

    public Long getId()
    {
		return Id;
	}

	public void setId(Long Id) 
	{
		this.Id = Id;
	}

	public String getType() 
	{
		return type;
	}

	public void setType(String type) 
	{
		this.type= type;
	}

	public String getDate() 
	{
		return date;
	}

	public void setDate(String date)
	{
		this.date= date;
	}

	public String getUser_id()
	{
		return User_id;
	}

	public void setUser_id(String user_id) 
	{
		User_id = user_id;
	}

	
    
}

    
  
    


