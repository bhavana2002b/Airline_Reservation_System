package com.demo.Entity;

import javax.persistence.Column;





import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Admin 
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Id",length= 20)
    private Long id;
    
    @Column(name="UserName",length= 30)
    private String username;
    
    @Column(name="Passsword",length = 30)
    private Double password;
    
    @Column(name="Email",length = 30)
    private String email;
    
    @Column(name="FullName",length = 30)
    private String fullname;



    public Long getid()
    {
		return id;
	}

	public void setid(Long id) 
	{
		this.id = id;
	}

	public String getUserName()
	{
		return username;
	}

	public void setUserName(String username) 
	{
		this.username = username;
	}
	

	public Double getPassword() 
	{
		return password;
	}

	public void setPassword(Double password) 
	{
		this.password = password;
	}

	public String getEmail() 
	{
		return email;
	}

	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	public String getFullName() 
	{
		return fullname;
	}

	public void setFullName(String fullname) 
	{
		this.fullname = fullname;
	}

	
	
}
    
    


