package com.demo.Repository;
import java.util.List;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.demo.Entity.Enquiry;





public interface EnquiryRepository extends JpaRepository<Enquiry, Integer>
{
	
@Query("select i from Enquiry i where i.id=?1")
List<Enquiry>findById(String id);
	
@Query("select i from Enquiry i where i.title=:title")	
List<Enquiry>findByTitle(@Param("Title") String title);

@Query("select i from Enquiry i where i.type=:type")	
List<Enquiry>findByType(@Param("Type") String type);

@Query("select i from Enquiry i where i.Date=:date")	
List<Enquiry>findBydate(@Param("date") String date);

@Query("select i from Enquiry i where i.user_id=:userid")	
List<Enquiry>findByUser_Id(@Param("user_id") String user_id);


//for testing purpose
Optional<Enquiry> findByFirstName(String name);

static Optional<Enquiry> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}

void deleteById(Long id);
}
