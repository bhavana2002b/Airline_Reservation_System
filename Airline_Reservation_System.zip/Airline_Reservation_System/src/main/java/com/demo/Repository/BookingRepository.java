package com.demo.Repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.demo.Entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer>
{
	
@Query("select i from Booking i where i.booking_id=?1")
List<Booking> findById(String id);
	
@Query("select i from Booking i where i.type=:type")	
List<Booking>	findByType(@Param("Type") String type);

@Query("select i from Booking i where i.date=:date")	
List<Booking>	 findByDate(@Param("date") String date);

@Query("select i from Booking i where i.user_id=:userid")	
List<Booking>	findByUser_Id(@Param("user_id") String user_id);

//for testing purpose
static Optional<Booking> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}void deleteById(Long id);










}
