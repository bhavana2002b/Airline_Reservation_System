package com.demo.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.demo.Entity.Ticket;


public interface TicketRepository extends JpaRepository<Ticket, Integer>
{
	
@Query("select i from Ticket i where i.TicketId=?1")
List<Ticket> findByTicketId(String ticketid);
	
@Query("select i from Ticket i where i.User_Id=:user_id")	
List<Ticket>	findByUser_Id(@Param("User_Id") String user_id);

@Query("select i from Ticket i where i.Flight_Id=:flight_id")	
List<Ticket>	findByFlight_Id(@Param("Flight_Id") String flight_id);

@Query("select i from Ticket i where i.SeatNumber=:seatnumber")	
List<Ticket>	findBySeatNumber(@Param("SeatNumber") String seatnumber);

@Query("select i from Ticket i where i.TicketStatus=:ticketstatus")	
List<Ticket>	findByTicketStatus(@Param("TicketStatus") String ticketstatus);

@Query("select i from Ticket i where i.TicketPrice=:ticketprice")	
List<Ticket>	findByTicketPrice(@Param("ticketprice") String ticketprice);

@Query("select i from Ticket i where i.BookingDate=:bookingdate")	
List<Ticket>	findByBookingDate(@Param("bookingdate") String bookingdate);



//for testing purpose
Optional<Ticket> findByticketid(String ticketid);

static Optional<Ticket> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}

void deleteById(Long id);




}
