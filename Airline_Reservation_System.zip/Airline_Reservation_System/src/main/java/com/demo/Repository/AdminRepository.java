package com.demo.Repository;

import java.util.List;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.Entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>
{
	
@Query("select i from Admin i where i.Adminid=?1")
List<Admin> getInstructorByAdminId(String adminid);
	
@Query("select i from Admin i where i.Username=:username")	
List<Admin>	findByUserName(@Param("Username") String username);

@Query("select i from Admin i where i.Password=:password")	
List<Admin>	findByPassword(@Param("password") String password);

@Query("select i from Admin i where i.Email=:email")	
List<Admin>	findByEmail(@Param("email") String email);

@Query("select i from Admin i where i.Fullname=:Fullname")	
List<Admin>	findByfullname(@Param("fullname") String fullname);


//for testing purpose
Optional<Admin> findByid(Long id);

static Optional<Admin> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}

void deleteById(Long id);




}
