package com.demo.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.demo.Entity.Flight;


public interface FlightRepository extends JpaRepository<Flight, Integer>
{
	
@Query("select i from Flight i where i.id=?1")
List<Flight> getFlightById(String id);
	
@Query("select i from Flight i where i.FlightNumber=:flightnumber")	
List<Flight>	 findByFlightNumber(@Param("FlightNumber") String flightnumber);

@Query("select i from Flight i where i.DepartureAirport=:departureairport")	
List<Flight>	 findByDepartureAirport(@Param("DepartureAirport") String departureairport);

@Query("select i from Flight i where i.DestinationAirport=:destinationairport")	
List<Flight>	 findByDestinationAirport(@Param("destinationairport") String destinationairport);

@Query("select i from Flight i where i.DepartureDatetime=:departuredatetime")	
List<Flight>	 findByDepartureDatetime(@Param("departuredatetime") String departuredatetime);

@Query("select i from Flight i where i.ArrivalDatetime=:arrivaldatetime")	
List<Flight>	findByArrivalDatetime(@Param("arrivaldatetime") String arrivaldatetime);

@Query("select i from Flight i where i.TotalSeats=:totalseats")	
List<Flight>	findByTotalSeats(@Param("totalseats") String totalseats);

@Query("select i from Flight i where AvailableSeats=:availableseats")	
List<Flight>    findByAvailableSeats(@Param("availableseats") String availableseats);

@Query("select i from Flight i where i.TicketPrice=:ticketprice")	
List<Flight>	findByTicketPrice(@Param("ticketprice") String ticketprice);

//for testing purpose
Optional<Flight> findByid(String id);

static Optional<Flight> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}

void deleteById(Long id);










}
