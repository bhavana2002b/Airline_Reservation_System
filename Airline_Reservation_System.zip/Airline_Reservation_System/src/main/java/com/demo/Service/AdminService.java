package com.demo.Service;

import java.util.List;

import com.demo.Entity.Admin;
import com.demo.Model.AdminDTO;

public interface AdminService
{
	
	public String createAdmin(AdminDTO adminDTO);
	public String deleteAdmin(Long id);
	public AdminDTO getAdminById (Long id);
    List<AdminDTO> getAllAdmins();
    public AdminDTO assignAdmin(int bookId, int aId);
    public AdminDTO updateAdmin(Long id,Admin adminDTO);
    List<AdminDTO> getAdminsByUsername(String username);
    List<AdminDTO> getAdminsByPassword(String password);
    List<AdminDTO> getAdminsByEmail(String email);
    List<AdminDTO> getAdminsByFullName(String fullname);
	public List<AdminDTO> getAdminsByUserName(String username);
	
	
	
	
	
	

	
	
	
}
