package com.demo.Service;

import java.util.List;




import com.demo.Entity.Ticket;
import com.demo.Model.TicketDTO;

public interface TicketService
{
public String createTicket(TicketDTO ticketDTO);
public String deleteTicket(Long Id);
public TicketDTO updateTicket(Long Id,Ticket ticketDTO);
public List<TicketDTO> getAllTickets();
public TicketDTO getTicketByTicketId(Long ticketId);
public List<TicketDTO> getTicketsByUser_Id(String user_id);
public List<TicketDTO> getTicketsByFlight_Id(String flight_id);
public List<TicketDTO> getTicketsBySeatNumber(String seatnumber);
public List<TicketDTO> getTicketsByTicketStatus(String ticketstatus);
public List<TicketDTO> getTicketsByTicketPrice(String ticketprice);
public List<TicketDTO> getTicketsByBookingDate(String bookingdate);
public TicketDTO updateTicketByDate(String bookingdate,Ticket ticket);
public TicketDTO getTicketById(int id); 
public Ticket assignTicket(int bookId, int aId);







}
