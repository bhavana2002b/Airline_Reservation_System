package com.demo.Service;


import java.util.List;

import com.demo.Entity.User;
import com.demo.Model.UserDTO;

public interface UserService {
public String createUser(UserDTO userDTO);
public String deleteUser(Long id);
public UserDTO updateUser(Long id,User userDTO);
public List<UserDTO> getAllUsers();
public UserDTO getUserById(Long id);
public UserDTO getUserByUser_Id(String user_id);
public List<UserDTO> getUsersByname(String name);
public List<UserDTO> getUsersByMobileNo(String mobileno);
public List<UserDTO> getUsersByEmailid(String emailid);
public List<UserDTO> getUsersByAddress(String address);
public UserDTO updateUserByAddress(String address,User user);
public UserDTO getUserById(int id); 
public User assignUser(int bookId, int aId);
List<UserDTO> getUsersByEmailId(String email);















}
