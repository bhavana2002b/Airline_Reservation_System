package com.demo.Service;

import java.util.List;


import com.demo.Entity.Payment;
import com.demo.Model.PaymentDTO;

public interface PaymentService {
public String createPayment(PaymentDTO paymentDTO);
public String deletePayment(Long id);
public PaymentDTO updatePayment(Long PaymentId,Payment paymentDTO);
public PaymentDTO getPaymentByPaymentId(Long Paymentid);
public List<PaymentDTO> getAllPayments();
public List<PaymentDTO> getPaymentsByBookingId(String bookingid);
public List<PaymentDTO> getPaymentsByPaymentDate(String paymentdate);
public List<PaymentDTO> getPaymentsByPaymentAmount(String paymentamount);
public List<PaymentDTO> getPaymentsByPaymentStatus(String paymentstatus);
public PaymentDTO updatePaymentBypaymentstatus(String paymentstatus,Payment payment);
public Payment assignPayment(int bookId, int aId);
public PaymentDTO getBydate(String date);
public PaymentDTO getByamount(String amount);
public PaymentDTO getBystatus(String status);






}
