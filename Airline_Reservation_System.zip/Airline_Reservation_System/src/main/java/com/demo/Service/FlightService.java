package com.demo.Service;

import java.util.List;


import com.demo.Entity.Flight;
import com.demo.Model.FlightDTO;

public interface FlightService 
{
public String createFlight(FlightDTO flightDTo);
public String deleteFlight(Long id);
public FlightDTO updateFlight(Long id,Flight flightDTO);
public List<FlightDTO> getAllFlights();
public List<FlightDTO> getFlightsByFlightNumber(String flightnumber);
public List<FlightDTO> getFlightsByDepartureAirport(String departureairport);
public List<FlightDTO> getFlightsByDestinationAirport(String destinationairport);
public List<FlightDTO> getFlightsByDepartureDatetime(String departuredatetime);
public List<FlightDTO> getFlightsByArrivalDatetime(String arrivaldatetime);
public List<FlightDTO> getFlightsByTotalSeats(String totalseats);
public List<FlightDTO> getFlightsByAvailableSeats(String availableseats);
public List<FlightDTO> getFlightsByTicketPrice(String ticketprice);
public FlightDTO getFlightByDate(String date);
public FlightDTO updateInsByDate(String date,Flight flight);
public FlightDTO getFlightBynumber(String number);
public FlightDTO getFlightBydestinationsirport(String destinationairport);
public FlightDTO getFlightByArrivaldatetime(String arrivaldatetime);
public FlightDTO getFlightById(Long id); 
public Flight assignFlight(int bookId, int aId);










	
}
