package com.demo.Service;


import java.util.List;



import com.demo.Entity.Booking;
import com.demo.Model.BookingDTO;

public interface BookingService 
{
	


public String createBooking(BookingDTO bookingDTO);
public String deleteBooking(Long Id);
public BookingDTO updateBooking(Long id,Booking bookingDTO);
public BookingDTO getBookingById(Long id);
public List<BookingDTO> getAllBookings();
public List<BookingDTO> getBookingsByType(String type);
public List<BookingDTO> getBookingsByDate(String date);
public BookingDTO updateInsByDate(String date,Booking booking);
public Booking assignBooking(int bookId, int aId);
public BookingDTO getByTitle(String title);
public BookingDTO getByDate(String date);
public List<BookingDTO> getBookingsByUser_Id(String user_id);

}
