package com.demo.Service;


import java.util.List;


import com.demo.Entity.Enquiry;
import com.demo.Model.EnquiryDTO;

public interface EnquiryService 
{
public String createEnquiry(EnquiryDTO EnquiryDTO);
public String deleteEnquiry(Long id);
public EnquiryDTO updateEnquiry(Long id,Enquiry enquiryDTO);
public List<EnquiryDTO> getAllEnquirys();
public List<EnquiryDTO> getEnquirysByTitle(String title);
public List<EnquiryDTO> getEnquirysByType(String type);
public List<EnquiryDTO> getEnquirysByDate(String date);
public EnquiryDTO updateEnquiryByDate(String date,Enquiry enquiry);
public EnquiryDTO getEnquiryById(Long id); 
public Enquiry assignEnquiry(int bookId, int aId);
public List<EnquiryDTO> getEnquirysByUser_Id(String user_id);




}



