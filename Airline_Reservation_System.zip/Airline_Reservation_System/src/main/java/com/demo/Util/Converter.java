package com.demo.Util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.demo.Entity.Admin;
import com.demo.Entity.Booking;
import com.demo.Entity.Enquiry;
import com.demo.Entity.Flight;
import com.demo.Entity.Payment;
import com.demo.Entity.Ticket;
import com.demo.Entity.User;
import com.demo.Model.AdminDTO;
import com.demo.Model.BookingDTO;
import com.demo.Model.EnquiryDTO;
import com.demo.Model.FlightDTO;
import com.demo.Model.PaymentDTO;
import com.demo.Model.TicketDTO;
import com.demo.Model.UserDTO;

@Component
public class Converter 
{
	
	//convert from DTO  to entity
	
		public Admin convertToAdminEntity(AdminDTO instructorDTO)
		{
			Admin instructor=new Admin();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public AdminDTO convertToAdminDTO(Admin instructor)
		{
			AdminDTO instructorDTO=new AdminDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
		
		
		//convert from DTO  to entity
		
		public Booking convertToBookingEntity(BookingDTO instructorDTO)
		{
			Booking instructor=new Booking();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public BookingDTO convertToBookingDTO(Booking instructor)
		{
			BookingDTO instructorDTO=new BookingDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
		
		
		//convert from DTO  to entity
		
		public Enquiry convertToEnquiryEntity(EnquiryDTO instructorDTO)
		{
			Enquiry instructor=new Enquiry();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public EnquiryDTO convertToEnquiryDTO(Enquiry instructor)
		{
			EnquiryDTO instructorDTO=new EnquiryDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
		
		//convert from DTO  to entity
		
		public Flight convertToFlightEntity(FlightDTO instructorDTO)
		{
			Flight instructor=new Flight();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public FlightDTO convertToFlightDTO(Flight instructor)
		{
			FlightDTO instructorDTO=new FlightDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
		
		//convert from DTO  to entity
		
		public Payment convertToPaymentEntity(PaymentDTO instructorDTO)
		{
			Payment instructor=new Payment();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public PaymentDTO convertToPaymentDTO(Payment instructor)
		{
			PaymentDTO instructorDTO=new PaymentDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
		
		//convert from DTO  to entity
		
		public Ticket convertToTicketEntity(TicketDTO instructorDTO)
		{
			Ticket instructor=new Ticket();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public TicketDTO convertToTicketDTO(Ticket instructor)
		{
			TicketDTO instructorDTO=new TicketDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
		
		//convert from DTO  to entity
		
		public User convertToUserEntity(UserDTO instructorDTO)
		{
			User instructor=new User();
			if(instructorDTO!=null)
			{
				BeanUtils.copyProperties(instructorDTO, instructor);
			}
			return instructor;
		}
		
		
		//covert from Entity to DTO
		public UserDTO convertToUserDTO(User instructor)
		{
			UserDTO instructorDTO=new UserDTO();
			if(instructor!=null)
			{
				BeanUtils.copyProperties(instructor, instructorDTO);
			}
			return instructorDTO;
		}
	
	
}
