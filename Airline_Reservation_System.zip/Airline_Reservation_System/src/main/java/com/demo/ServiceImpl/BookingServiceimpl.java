package com.demo.ServiceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Entity.Booking;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.BookingDTO;
import com.demo.Repository.BookingRepository;
import com.demo.Service.BookingService;
import com.demo.Util.Converter;

@Service 
public class BookingServiceimpl implements BookingService 
{

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createBooking(BookingDTO bookingDTO)
    {
        Booking booking = converter.convertToBookingEntity(bookingDTO);
        bookingRepository.save(booking);
        return "Booking created successfully!";
    }

    @Override
    public String deleteBooking(Long Id)
    {
        Optional<Booking> booking = BookingRepository.findById(Id);
        if (booking.isPresent()) 
        {
            bookingRepository.deleteById(Id);
            return "Booking deleted successfully!";
        } 
        else
        {
            throw new ResourceNotFoundException("Booking", "Id", Id);
        }
    }

    @Override
    public BookingDTO updateBooking(Long Id, Booking bookingDTO) 
    {
        Booking existingBooking = BookingRepository.findById(Id).orElseThrow(() -> new ResourceNotFoundException("Booking", "Id", Id));
        
        existingBooking.setType(bookingDTO.getType());
        existingBooking.setDate(bookingDTO.getDate());
        existingBooking.setUser_id(bookingDTO.getUser_id());
       
        // Update other fields as necessary

        bookingRepository.save(existingBooking);
        return converter.convertToBookingDTO(existingBooking);
    }

    @Override
    public BookingDTO getBookingById(Long Id) 
    {
        Booking booking = BookingRepository.findById(Id)
                .orElseThrow(() -> new ResourceNotFoundException("Admin", "Id", Id));
        return converter.convertToBookingDTO(booking);
    }

    @Override
    public List<BookingDTO> getAllBookings() 
    {
        List<Booking> bookings = bookingRepository.findAll();
        List<BookingDTO> bookingDTOs = new ArrayList<>();
        for (Booking booking : bookings) {
            bookingDTOs.add(converter.convertToBookingDTO(booking));
        }
        return bookingDTOs;
    }
    
    @Override
    public List<BookingDTO> getBookingsByType(String type)
    {
       
        List<Booking> bookings = bookingRepository.findByType(type);
        List<BookingDTO> bookingDTOs = new ArrayList<>();
        for (Booking booking : bookings) 
        {
            bookingDTOs.add(converter.convertToBookingDTO(booking));
        }
        return bookingDTOs;
    }
    
    
    public List<BookingDTO> getBookingsByDate(String date)
    {
        List<Booking> bookings = bookingRepository.findByDate(date);
        List<BookingDTO> bookingDTOs = new ArrayList<>();
        for (Booking booking : bookings) 
        {
            bookingDTOs.add(converter.convertToBookingDTO(booking));
        }
        return bookingDTOs;
    }
   
    @Override
    public List<BookingDTO> getBookingsByUser_Id(String user_id)
    {
        List<Booking> bookings = bookingRepository.findByUser_Id(user_id);
        List<BookingDTO> bookingDTOs = new ArrayList<>();
        for (Booking booking : bookings) 
        {
            bookingDTOs.add(converter.convertToBookingDTO(booking));
        }
        return bookingDTOs;
    }

	@Override
	public BookingDTO updateInsByDate(String date, Booking booking) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking assignBooking(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDTO getByTitle(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDTO getByDate(String date) {
		// TODO Auto-generated method stub
		return null;
	}

	
}



