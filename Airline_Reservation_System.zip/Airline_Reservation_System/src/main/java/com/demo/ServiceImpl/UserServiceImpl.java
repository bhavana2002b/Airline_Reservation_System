package com.demo.ServiceImpl;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Entity.User;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.UserDTO;
import com.demo.Repository.UserRepository;
import com.demo.Service.UserService;
import com.demo.Util.Converter;

@Service
public class UserServiceImpl implements UserService
{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createUser(UserDTO userDTO) 
    {
        User user = converter.convertToUserEntity(userDTO);
        userRepository.save(user);
        return "User created successfully!";
    }

    @Override
    public String deleteUser(Long id) 
    {
        Optional<User> user = UserRepository.findById(id);
        if (user.isPresent()) {
            userRepository.deleteById(id);
            return "User deleted successfully!";
        } else {
            throw new ResourceNotFoundException("User", "Id", id);
        }
    }

   
    @Override
    public UserDTO updateUser(Long Id, User userDTO) 
    {
        User existingUser = UserRepository.findById(Id).orElseThrow(() -> new ResourceNotFoundException("User", "Id", Id));
        
        existingUser.setName(userDTO.getName());
        existingUser.setMobileNo(userDTO.getMobileNo());
        existingUser.setEmailId(userDTO.getEmailId());
       
        // Update other fields as necessary

        userRepository.save(existingUser);
        return converter.convertToUserDTO(existingUser);
    }

    @Override
    public UserDTO getUserById(Long id)
    {
        User user = UserRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", id));
        return converter.convertToUserDTO(user);
    }

    @Override
    public List<UserDTO> getAllUsers()
    {
        List<User> users = userRepository.findAll();
        List<UserDTO> userDTOs = new ArrayList<>();
        for (User user : users) {
            userDTOs.add(converter.convertToUserDTO(user));
        }
        return userDTOs;
    }
    

    @Override
    public List<UserDTO> getUsersByname(String name)
    {
       
        List<User> users = userRepository.findByName(name);
        List<UserDTO> userDTOs = new ArrayList<>();
        for (User user : users) 
        {
            userDTOs.add(converter.convertToUserDTO(user));
        }
        return userDTOs;
    }
    
    @Override
    public List<UserDTO> getUsersByMobileNo(String mobileno)
    {
        List<User> users = userRepository.findByMobileNo(mobileno);
        List<UserDTO> userDTOs = new ArrayList<>();
        for (User user : users) 
        {
            userDTOs.add(converter.convertToUserDTO(user));
        }
        return userDTOs;
    }
   
    public List<UserDTO> getUsersByEmailId(String emailid)
    {
        List<User> users = userRepository.findByEmailId(emailid);
        List<UserDTO> userDTOs = new ArrayList<>();
        for (User user : users) 
        {
            userDTOs.add(converter.convertToUserDTO(user));
        }
        return userDTOs;
    }
   
  
    public List<UserDTO> getUsersByAddress(String address)
    {
        List<User> users = userRepository.findByAddress(address);
        List<UserDTO> userDTOs = new ArrayList<>();
        for (User user : users) 
        {
            userDTOs.add(converter.convertToUserDTO(user));
        }
        return userDTOs;
    }

	@Override
	public UserDTO getUserByUser_Id(String user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDTO> getUsersByEmailid(String emailid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDTO updateUserByAddress(String address, User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDTO getUserById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User assignUser(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
