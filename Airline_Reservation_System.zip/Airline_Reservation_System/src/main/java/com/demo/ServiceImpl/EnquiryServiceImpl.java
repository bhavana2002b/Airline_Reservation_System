package com.demo.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.demo.Entity.Enquiry;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.EnquiryDTO;
import com.demo.Repository.EnquiryRepository;
import com.demo.Service.EnquiryService;
import com.demo.Util.Converter;

@Service
public class EnquiryServiceImpl implements EnquiryService
{

    @Autowired
    private EnquiryRepository enquiryRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createEnquiry(EnquiryDTO enquiryDTO) 
    {
        Enquiry enquiry = converter.convertToEnquiryEntity(enquiryDTO);
        enquiryRepository.save(enquiry);
        return "Enquiry created successfully!";
    }

    @Override
    public String deleteEnquiry(Long id) 
    {
        Optional<Enquiry> enquiry = EnquiryRepository.findById(id);
        if (enquiry.isPresent()) {
            enquiryRepository.deleteById(id);
            return "User deleted successfully!";
        } else {
            throw new ResourceNotFoundException("User", "Id", id);
        }
    }

   
    @Override
    public EnquiryDTO updateEnquiry(Long Id, Enquiry enquiryDTO) 
    {
        Enquiry existingEnquiry = EnquiryRepository.findById(Id).orElseThrow(() -> new ResourceNotFoundException("Enquiry", "Id", Id));
        
        existingEnquiry.setTitle(enquiryDTO.getTitle());
        existingEnquiry.setType(enquiryDTO.getType());
        existingEnquiry.setDate(enquiryDTO.getDate());
        existingEnquiry.setUser_id(enquiryDTO.getUser_id());
       
        // Update other fields as necessary

        enquiryRepository.save(existingEnquiry);
        return converter.convertToEnquiryDTO(existingEnquiry);
    }

    @Override
    public EnquiryDTO getEnquiryById(Long id)
    {
        Enquiry enquiry = EnquiryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enquiry", "Id", id));
        return converter.convertToEnquiryDTO(enquiry);
    }

    @Override
    public List<EnquiryDTO> getAllEnquirys()
    {
        List<Enquiry> enquirys = enquiryRepository.findAll();
        List<EnquiryDTO> enquiryDTOs = new ArrayList<>();
        for (Enquiry enquiry : enquirys) {
            enquiryDTOs.add(converter.convertToEnquiryDTO(enquiry));
        }
        return enquiryDTOs;
    }
    

    @Override
    public List<EnquiryDTO> getEnquirysByTitle(String title)
    {
       
        List<Enquiry> enquirys = enquiryRepository.findByTitle(title);
        List<EnquiryDTO> enquiryDTOs = new ArrayList<>();
        for (Enquiry enquiry : enquirys) 
        {
            enquiryDTOs.add(converter.convertToEnquiryDTO(enquiry));
        }
        return enquiryDTOs;
    }
    
    @Override
    public List<EnquiryDTO> getEnquirysByType(String type)
    {
        List<Enquiry> enquirys = enquiryRepository.findByType(type);
        List<EnquiryDTO> enquiryDTOs = new ArrayList<>();
        for (Enquiry enquiry : enquirys) 
        {
            enquiryDTOs.add(converter.convertToEnquiryDTO(enquiry));
        }
        return enquiryDTOs;
    }
   
    public List<EnquiryDTO> getEnquirysByDate(String date)
    {
        List<Enquiry> enquirys = enquiryRepository.findBydate(date);
        List<EnquiryDTO> enquiryDTOs = new ArrayList<>();
        for (Enquiry enquiry : enquirys) 
        {
            enquiryDTOs.add(converter.convertToEnquiryDTO(enquiry));
        }
        return enquiryDTOs;
    }
   
  
    @Override
    public List<EnquiryDTO> getEnquirysByUser_Id(String user_id)
    {
        List<Enquiry> enquirys = enquiryRepository.findByUser_Id(user_id);
        List<EnquiryDTO> enquiryDTOs = new ArrayList<>();
        for (Enquiry enquiry : enquirys) 
        {
            enquiryDTOs.add(converter.convertToEnquiryDTO(enquiry));
        }
        return enquiryDTOs;
    }

	@Override
	public EnquiryDTO updateEnquiryByDate(String date, Enquiry enquiry) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Enquiry assignEnquiry(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}
}
