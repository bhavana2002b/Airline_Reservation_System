package com.demo.ServiceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Entity.Ticket;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.TicketDTO;
import com.demo.Repository.TicketRepository;
import com.demo.Service.TicketService;
import com.demo.Util.Converter;

@Service 
public class TicketServiceimpl implements TicketService 
{

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createTicket(TicketDTO ticketDTO)
    {
        Ticket ticket = converter.convertToTicketEntity(ticketDTO);
        ticketRepository.save(ticket);
        return "Ticket created successfully!";
    }

    @Override
    public String deleteTicket(Long TicketId)
    {
        Optional<Ticket> ticket = TicketRepository.findById(TicketId);
        if (ticket.isPresent()) 
        {
            ticketRepository.deleteById(TicketId);
            return "Ticket deleted successfully!";
        } 
        else
        {
            throw new ResourceNotFoundException("Ticket", "Id", TicketId);
        }
    }

    @Override
    public TicketDTO updateTicket(Long TicketId, Ticket ticketDTO) 
    {
        Ticket existingTicket = TicketRepository.findById(TicketId).orElseThrow(() -> new ResourceNotFoundException("Ticket", "Id", TicketId));
        
        existingTicket.setUser_Id(ticketDTO.getUser_Id());
        existingTicket.setFlight_Id(ticketDTO.getFlight_Id());
        existingTicket.setSeatNumber(ticketDTO.getSeatNumber());
        existingTicket.setTicketStatus(ticketDTO.getTicketStatus());
        existingTicket.setTicketPrice(ticketDTO.getTicketPrice());
        existingTicket.setBookingDate(ticketDTO.getBookingDate());
       
     
     // Update other fields as necessary
    ticketRepository.save(existingTicket);
        return converter.convertToTicketDTO(existingTicket);
    }

    @Override
    public TicketDTO getTicketByTicketId(Long TicketId) 
    {
        Ticket ticket = TicketRepository.findById(TicketId)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket", "Id", TicketId));
        return converter.convertToTicketDTO(ticket);
    }

    @Override
    public List<TicketDTO> getAllTickets() 
    {
        List<Ticket> tickets = ticketRepository.findAll();
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets)
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }
    
    @Override
    public List<TicketDTO> getTicketsByUser_Id(String user_id)
    {
       
        List<Ticket> tickets = ticketRepository.findByUser_Id(user_id);
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets) 
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }
    
    
    public List<TicketDTO> getTicketsByFlight_Id(String flight_id)
    {
        List<Ticket> tickets = ticketRepository.findByFlight_Id(flight_id);
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets) 
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }
   
    @Override
    public List<TicketDTO> getTicketsBySeatNumber(String seatnumber)
    {
        List<Ticket> tickets = ticketRepository.findBySeatNumber(seatnumber);
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets) 
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }
    @Override
    public List<TicketDTO> getTicketsByTicketStatus(String ticketstatus)
    {
        List<Ticket> tickets = ticketRepository.findByTicketStatus(ticketstatus);
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets) 
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }
    @Override
    public List<TicketDTO> getTicketsByTicketPrice(String ticketprice)
    {
        List<Ticket> tickets = ticketRepository.findByTicketPrice(ticketprice);
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets) 
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }
    
    @Override
    public List<TicketDTO> getTicketsByBookingDate(String bookingdate)
    {
        List<Ticket> tickets = ticketRepository.findByBookingDate(bookingdate);
        List<TicketDTO> ticketDTOs = new ArrayList<>();
        for (Ticket ticket : tickets) 
        {
            ticketDTOs.add(converter.convertToTicketDTO(ticket));
        }
        return ticketDTOs;
    }

	@Override
	public TicketDTO updateTicketByDate(String bookingdate, Ticket ticket) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TicketDTO getTicketById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Ticket assignTicket(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}
    

	
}
