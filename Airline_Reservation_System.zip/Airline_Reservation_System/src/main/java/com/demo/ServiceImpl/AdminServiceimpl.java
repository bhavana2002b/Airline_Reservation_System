package com.demo.ServiceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Entity.Admin;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.AdminDTO;
import com.demo.Repository.AdminRepository;
import com.demo.Service.AdminService;
import com.demo.Util.Converter;

@Service 
public class AdminServiceimpl implements AdminService 
{

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createAdmin(AdminDTO adminDTO)
    {
        Admin admin = converter.convertToAdminEntity(adminDTO);
        adminRepository.save(admin);
        return "Admin created successfully!";
    }

    @Override
    public String deleteAdmin(Long Id)
    {
        Optional<Admin> admin = AdminRepository.findById(Id);
        if (admin.isPresent()) 
        {
            adminRepository.deleteById(Id);
            return "Admin deleted successfully!";
        } 
        else
        {
            throw new ResourceNotFoundException("Admin", "Id", Id);
        }
    }

    @Override
    public AdminDTO updateAdmin(Long Id, Admin adminDTO) 
    {
        Admin existingAdmin = AdminRepository.findById(Id).orElseThrow(() -> new ResourceNotFoundException("Admin", "Id", Id));
        
        existingAdmin.setUserName(adminDTO.getUserName());
        existingAdmin.setPassword(adminDTO.getPassword());
        existingAdmin.setEmail(adminDTO.getEmail());
        existingAdmin.setFullName(adminDTO.getFullName());
        // Update other fields as necessary

        adminRepository.save(existingAdmin);
        return converter.convertToAdminDTO(existingAdmin);
    }

    @Override
    public AdminDTO getAdminById(Long Id) 
    {
        Admin admin = AdminRepository.findById(Id)
                .orElseThrow(() -> new ResourceNotFoundException("Admin", "Id", Id));
        return converter.convertToAdminDTO(admin);
    }

    @Override
    public List<AdminDTO> getAllAdmins() 
    {
        List<Admin> admins = adminRepository.findAll();
        List<AdminDTO> adminDTOs = new ArrayList<>();
        for (Admin admin : admins) {
            adminDTOs.add(converter.convertToAdminDTO(admin));
        }
        return adminDTOs;
    }

    @Override
    public List<AdminDTO> getAdminsByUsername(String username)
    {
       
        List<Admin> admins = adminRepository.findByUserName(username);
        List<AdminDTO> adminDTOs = new ArrayList<>();
        for (Admin admin : admins) 
        {
            adminDTOs.add(converter.convertToAdminDTO(admin));
        }
        return adminDTOs;
    }
    
    
    

    @Override
    public List<AdminDTO> getAdminsByPassword(String password)
    {
        List<Admin> admins = adminRepository.findByPassword(password);
        List<AdminDTO> adminDTOs = new ArrayList<>();
        for (Admin admin : admins) 
        {
            adminDTOs.add(converter.convertToAdminDTO(admin));
        }
        return adminDTOs;
    }
   
    @Override
    public List<AdminDTO> getAdminsByEmail(String email)
    {
        List<Admin> admins = adminRepository.findByEmail(email);
        List<AdminDTO> adminDTOs = new ArrayList<>();
        for (Admin admin : admins) 
        {
            adminDTOs.add(converter.convertToAdminDTO(admin));
        }
        return adminDTOs;
    }
   
    @Override
    public List<AdminDTO> getAdminsByFullName(String fullname)
    {
        List<Admin> admins = adminRepository.findByfullname(fullname);
        List<AdminDTO> adminDTOs = new ArrayList<>();
        for (Admin admin : admins) 
        {
            adminDTOs.add(converter.convertToAdminDTO(admin));
        }
        return adminDTOs;
    }

	@Override
	public AdminDTO assignAdmin(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AdminDTO> getAdminsByUserName(String username) {
		// TODO Auto-generated method stub
		return null;
	}
	

	
}

