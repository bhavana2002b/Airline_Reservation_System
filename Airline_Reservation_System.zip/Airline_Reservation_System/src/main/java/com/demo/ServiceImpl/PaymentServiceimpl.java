package com.demo.ServiceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Entity.Payment;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.PaymentDTO;
import com.demo.Repository.PaymentRepository;
import com.demo.Service.PaymentService;
import com.demo.Util.Converter;

@Service 
public class PaymentServiceimpl implements PaymentService 
{

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createPayment(PaymentDTO paymentDTO)
    {
        Payment payment = converter.convertToPaymentEntity(paymentDTO);
        paymentRepository.save(payment);
        return "Payment created successfully!";
    }

    @Override
    public String deletePayment(Long PaymentId)
    {
        Optional<Payment> payment = PaymentRepository.findById(PaymentId);
        if (payment.isPresent()) 
        {
            paymentRepository.deleteById(PaymentId);
            return "Payment deleted successfully!";
        } 
        else
        {
            throw new ResourceNotFoundException("Payment", "Id", PaymentId);
        }
    }

    @Override
    public PaymentDTO updatePayment(Long PaymentId, Payment paymentDTO) 
    {
        Payment existingPayment = PaymentRepository.findById(PaymentId).orElseThrow(() -> new ResourceNotFoundException("Payment", "Id", PaymentId));
        
        existingPayment.setPaymentId(paymentDTO.getPaymentId());
        existingPayment.setBookingId(paymentDTO.getBookingId());
        existingPayment.setPaymentDate(paymentDTO.getPaymentDate());
        existingPayment.setPaymentAmount(paymentDTO.getPaymentAmount());
        existingPayment.setPaymentStatus(paymentDTO.getPaymentStatus());
       
        // Update other fields as necessary

        paymentRepository.save(existingPayment);
        return converter.convertToPaymentDTO(existingPayment);
    }

    @Override
    public PaymentDTO getPaymentByPaymentId(Long PaymentId) 
    {
        Payment payment = PaymentRepository.findById(PaymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "Id", PaymentId));
        return converter.convertToPaymentDTO(payment);
    }

    @Override
    public List<PaymentDTO> getAllPayments() 
    {
        List<Payment> payments = paymentRepository.findAll();
        List<PaymentDTO> paymentDTOs = new ArrayList<>();
        for (Payment payment : payments) 
        {
            paymentDTOs.add(converter.convertToPaymentDTO(payment));
        }
        return paymentDTOs;
    }
    
    @Override
    public List<PaymentDTO> getPaymentsByBookingId(String bookingid)
    {
       
        List<Payment> payments = paymentRepository.findByBookingId(bookingid);
        List<PaymentDTO> paymentDTOs = new ArrayList<>();
        for (Payment payment : payments) 
        {
            paymentDTOs.add(converter.convertToPaymentDTO(payment));
        }
        return paymentDTOs;
    }
    
    
    public List<PaymentDTO> getPaymentsByPaymentDate(String paymentdate)
    {
        List<Payment> payments = paymentRepository.findByPaymentDate(paymentdate);
        List<PaymentDTO> paymentDTOs = new ArrayList<>();
        for (Payment payment : payments) 
        {
            paymentDTOs.add(converter.convertToPaymentDTO(payment));
        }
        return paymentDTOs;
    }
   
    @Override
    public List<PaymentDTO> getPaymentsByPaymentAmount(String paymentamount)
    {
        List<Payment> payments = paymentRepository.findByPaymentAmount(paymentamount);
        List<PaymentDTO> paymentDTOs = new ArrayList<>();
        for (Payment payment : payments) 
        {
            paymentDTOs.add(converter.convertToPaymentDTO(payment));
        }
        return paymentDTOs;
    }
    @Override
    public List<PaymentDTO> getPaymentsByPaymentStatus(String paymentstatus)
    {
        List<Payment> payments = paymentRepository.findByPaymentStatus(paymentstatus);
        List<PaymentDTO> paymentDTOs = new ArrayList<>();
        for (Payment payment : payments) 
        {
            paymentDTOs.add(converter.convertToPaymentDTO(payment));
        }
        return paymentDTOs;
    }

	@Override
	public PaymentDTO updatePaymentBypaymentstatus(String paymentstatus, Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Payment assignPayment(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentDTO getBydate(String date) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentDTO getByamount(String amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentDTO getBystatus(String status) {
		// TODO Auto-generated method stub
		return null;
	}
    
    

	
}



