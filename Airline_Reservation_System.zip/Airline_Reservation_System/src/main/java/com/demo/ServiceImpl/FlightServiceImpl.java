package com.demo.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.demo.Entity.Flight;
import com.demo.Exception.ResourceNotFoundException;
import com.demo.Model.FlightDTO;
import com.demo.Repository.FlightRepository;
import com.demo.Service.FlightService;
import com.demo.Util.Converter;

@Service
public class FlightServiceImpl implements FlightService
{

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private Converter converter;  // Assuming a utility to convert between entity and DTO

    @Override
    public String createFlight(FlightDTO flightDTO) 
    {
        Flight flight = converter.convertToFlightEntity(flightDTO);
        flightRepository.save(flight);
        return "Flight created successfully!";
    }

    @Override
    public String deleteFlight(Long id) 
    {
        Optional<Flight> flight = FlightRepository.findById(id);
        if (flight.isPresent())
        {
            flightRepository.deleteById(id);
            return "Flight deleted successfully!";
        } else {
            throw new ResourceNotFoundException("Flight", "Id", id);
        }
    }

   
    @Override
    public FlightDTO updateFlight(Long Id, Flight flightDTO) 
    {
        Flight existingFlight = FlightRepository.findById(Id).orElseThrow(() -> new ResourceNotFoundException("Flight", "Id", Id));
        
        existingFlight.setFlightNumber(flightDTO.getFlightNumber());
        existingFlight.setDepartureAirport(flightDTO.getDepartureAirport());
        existingFlight.setDestinationAirport(flightDTO.getDestinationAirport());
        existingFlight.setDepartureDatetime(flightDTO.getDepartureDatetime());
        existingFlight.setArrivalDatetime(flightDTO.getArrivalDatetime());
        existingFlight.setTotalSeats(flightDTO.getTotalSeats());
        existingFlight.setAvailableSeats(flightDTO.getAvailableSeats());
        existingFlight.setTicketPrice(flightDTO.getTicketPrice());
       
        // Update other fields as necessary

        flightRepository.save(existingFlight);
        return converter.convertToFlightDTO(existingFlight);
    }

    @Override
    public FlightDTO getFlightById(Long id)
    {
        Flight flight = FlightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight", "Id", id));
        return converter.convertToFlightDTO(flight);
    }

    @Override
    public List<FlightDTO> getAllFlights()
    {
        List<Flight> flights = flightRepository.findAll();
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
    

    @Override
    public List<FlightDTO> getFlightsByFlightNumber(String flightnumber)
    {
       
        List<Flight> flights = flightRepository.findByFlightNumber(flightnumber);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
    
    @Override
    public List<FlightDTO> getFlightsByDepartureAirport(String departureairport)
    {
        List<Flight> flights = flightRepository.findByDepartureAirport(departureairport);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
   
    public List<FlightDTO> getFlightsByDestinationAirport(String destinationairport)
    {
        List<Flight> flights = flightRepository.findByDestinationAirport(destinationairport);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
   
  
    @Override
    public List<FlightDTO> getFlightsByDepartureDatetime(String departuredatetime)
    {
        List<Flight> flights = flightRepository.findByDepartureDatetime(departuredatetime);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
    
    @Override
    public List<FlightDTO> getFlightsByArrivalDatetime(String arrivaldatetime)
    {
        List<Flight> flights = flightRepository.findByArrivalDatetime(arrivaldatetime);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
    
    @Override
    public List<FlightDTO> getFlightsByTotalSeats(String totalseats)
    {
        List<Flight> flights = flightRepository.findByTotalSeats(totalseats);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
    
    @Override
    public List<FlightDTO> getFlightsByAvailableSeats(String availableseats)
    {
        List<Flight> flights = flightRepository.findByAvailableSeats(availableseats);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }
    @Override
    public List<FlightDTO> getFlightsByTicketPrice(String ticketprice)
    {
        List<Flight> flights = flightRepository.findByTicketPrice(ticketprice);
        List<FlightDTO> flightDTOs = new ArrayList<>();
        for (Flight flight : flights) 
        {
            flightDTOs.add(converter.convertToFlightDTO(flight));
        }
        return flightDTOs;
    }

	@Override
	public FlightDTO getFlightByDate(String date) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightDTO updateInsByDate(String date, Flight flight) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightDTO getFlightBynumber(String number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightDTO getFlightBydestinationsirport(String destinationairport) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlightDTO getFlightByArrivaldatetime(String arrivaldatetime) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Flight assignFlight(int bookId, int aId) {
		// TODO Auto-generated method stub
		return null;
	}

	
    
    
    
    

}
